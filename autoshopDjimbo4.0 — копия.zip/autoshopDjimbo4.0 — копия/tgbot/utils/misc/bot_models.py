# - *- coding: utf- 8 - *-
from aiogram.fsm.context import FSMContext

from tgbot.services.api_session import AsyncRequestSession

FSM = FSMContext
ARS = AsyncRequestSession
